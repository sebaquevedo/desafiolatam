a = [1,2,3,4,5]
a.each do |i|
	puts i + 1
end
print a