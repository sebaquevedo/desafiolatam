class Alumno
 def initialize()
 @notas = []
 nombre = "Humberto"
 end
end