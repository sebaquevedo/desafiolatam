class Zombie
	def initialize
		@brains = 0
		@speed = 5
		@km = 0
	end

	def walk
			@km += @speed
	end

	def gps
		puts @km
	end
end

class Molde

end

moldes = []
10.times do
moldes << Molde.new
end

print moldes

# crear clase y usar su comportamiento

class Zombie
 def saludar
 	puts "braaaains"
 end
end
z = Zombie.new
z.saludar()
#crear clase y definir nuevos comportamientos 
class Zombie
	def empezar
		@brains = 0 
	end

	def saludar
		@brains +=1
		puts "braaains #{@brains}" 
	end

end
z = Zombie.new
z.empezar()

z2 = Zombie.new
z2.empezar()

10.times.do
z1.saludar
z2.saludar
#definir nuevos metodos
class Zombie
	def initialize
		@brains = 0
		@speed = 5
		@km = 0
	end

	def walk
			@km += @speed
	end

	def gps
		puts @km
	end
end

"no puedo modificar una variable de instancia desde afuera"
"no puedo modificar una variable de instancia desde afuera"
"no puedo modificar una variable de instancia desde afuera"

"no puedo modificar una variable de instancia desde afuera"
"no puedo modificar una variable de instancia desde afuera"
"no puedo modificar una variable de instancia desde afuera"
"no puedo modificar una variable de instancia desde afuera"
"no puedo modificar una variable de instancia desde afuera"

"no puedo modificar una variable de instancia desde afuera""no puedo modificar una variable de instancia desde afuera"
