a = 5
a = 6
b1 = "hola"
1b = "hola" 