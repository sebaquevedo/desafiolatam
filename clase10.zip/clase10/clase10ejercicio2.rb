puts "escriba su nombre"
nombre = gets.chomp
puts "escriba su edad"
edad = gets.chomp

puts nombre+edad 