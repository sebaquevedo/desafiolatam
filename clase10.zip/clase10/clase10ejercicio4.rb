#fixnums
puts " ingrese dos numeros"
numero1=gets.chomp.to_i
numero2=gets.chomp.to_i
if numero1 > numero2
	puts "el primer numero es mayor" 
else puts "el segundo numero es mayor"
end