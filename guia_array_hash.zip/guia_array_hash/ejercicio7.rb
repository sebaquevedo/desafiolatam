require 'pp'

a = [1,2,3,9,12,31, "domingo"]
b = ["lunes","martes","miércoles","jueves","viernes","sábado","domingo"]

#1 concatenar

p a.concat b

# #2 union

p a | b

# #3  interseccion

p a & b

#4

p a.zip b






