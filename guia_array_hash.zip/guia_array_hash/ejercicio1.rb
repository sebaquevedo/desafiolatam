
a =  [1,2,3,9,1,4,5,2,3,6,6]

# #1 mostrar primer elemento
# puts a [0]
# #2 mostrar ultimo elemento
# puts a [-1]
# #3 
# puts a
# #4
# a.each_with_index do |value,index|
# 	puts "#{value} #{index}"
# end
# #5
# a.each_with_index do |value,index|
# 	puts value if index.even?
# end

# 6
#puts a.include?(10)