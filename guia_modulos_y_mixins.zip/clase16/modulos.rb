module Foo
	def self.bar
			puts "Desafio !!!"
			puts "LATAM !!!"
		end
	end

Foo.bar