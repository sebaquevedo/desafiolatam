class PagesController < ApplicationController
  def pag1
  end
end
